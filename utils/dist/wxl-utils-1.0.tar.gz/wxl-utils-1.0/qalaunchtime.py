#!/usr/bin/env python
import os
import sys
import subprocess
import re
import math
import time
from mail import send_email
from adb import adb
from infocollector import collector as ic
from mysqlwrapper import wrapper as sw
from uiautomator import device as d
DBG = False
SLEEP_TIME_TO_BE_STABLE = 5
TAGS = "gfx wm am input view res freq dalvik freq sched idle freq"
SYSTRACE_FLAG = False


coornidate_scale_dic = {
    "malata8": [1.5, 0.7],
}


def start_tracing(tags):
    if SYSTRACE_FLAG:
        adb.cmd("shell \"atrace -b 30000 --async_start %s\"" % (tags)).communicate()


def stop_tracing(out):
    if SYSTRACE_FLAG:
        adb.cmd("shell \"atrace --async_dump -z\" > out.trace").communicate()
        cmd = "systrace.py --from-file=out.trace -o %s" % out
        os.system(cmd)

def removeFromLRU():
    adb.cmd("shell input keyevent 187").communicate()
    time.sleep(1)
    adb.cmd("shell input swipe 200 674 700 674 250").communicate()
    time.sleep(1)


def amstop(packageName):
    adb.cmd("shell am force-stop %s" % packageName).communicate()
    time.sleep(1)

'''
input:
[Info]: Gesture started at -7635284 - 134518601  (638381583516)
output:
638381583516
'''
def getStartpoint(touchscreen, x, y):
    out = adb.cmd("shell /data/eventHunter -i %s -g TOUCH -p %d -q %d -t B" % (
        touchscreen, x, y)).communicate()[0].decode('utf-8').splitlines()[0].strip()
    if re.findall("\(\d*", out) != []:
        out = out.split("(")[1].strip()[:-1]
    else:
        print "Error: make sure /data/eventHuner exists."
        sys.exit()
    return long(out)


def getEndpoint(layer):
    resContent = adb.cmd("shell dumpsys SurfaceFlinger --latency %s" % (layer)).communicate()[0].decode('utf-8').splitlines()
    endpoint = 0
    length = len(resContent)
    for i in range(length):
        if re.findall("0\s*0\s*0", resContent[i]) == [] and i != 0 and i != length - 1:
            endpoint = long(resContent[i].split()[1])
            break
    return endpoint


def getLaunchTime(x, y, layer, touchscreen, duration):
    startpoint = getStartpoint(touchscreen, x, y)
    time.sleep(duration)
    endpoint = getEndpoint(layer)
    if DBG:
        print ("start: %d, end: %d") % (startpoint, endpoint)
    launchtime = endpoint - startpoint
    launchtime /= 1000 * 1000

    return launchtime


def getTouchNode():
    devices_info_list = adb.cmd("shell cat /proc/bus/input/devices").communicate()[0].decode('utf-8').splitlines()
    '''
    something like this
    I: Bus=0018 Vendor=0000 Product=0000 Version=0000
    N: Name="r69001-touchscreen"
    P: Phys=
    S: Sysfs=/devices/pci0000:00/0000:00:09.2/i2c-7/7-0055/input/input0
    U: Uniq=

    B: PROP=0
    B: EV=9
    B: ABS=6608000 0
    '''
    position = 0

    for item in devices_info_list:
        if "touch" in item or "ts" in item or "ft5x0x" in item:
            position = devices_info_list.index(item)
            break
    '''
    parse the below string to get the event0
    H: Handlers=event0
    '''
    if position != 0:
        while True:
            handler_info = devices_info_list[position]
            touch_event_position = re.findall('event\d', handler_info)
            if touch_event_position != []:
                touch_postion = "/dev/input/%s" % touch_event_position[0]
                break
            position += 1
        return touch_postion
    else:
        print "Error: counldn't find touch pos!"
        return None


def doQALaunchTime(qaArgs):
    uiobject_name = qaArgs.get("uiobject_name")
    bounds = d(text=uiobject_name).info.get("bounds")
    x = (bounds.get("left") + bounds.get("right")) / 2
    y = (bounds.get("top") + bounds.get("bottom")) / 2
   # x = x * 0.667
   # y = y * 0.667

    layer = qaArgs.get("layer")
    duration = qaArgs.get("sleep_time")
    packageName = qaArgs.get("packageName")
    repeatCount = qaArgs.get("repeat")
    outputName = qaArgs.get("outName")
    touchscreen = getTouchNode()
    outfd = open(outputName, "w")
    getLaunchTime(x, y, layer, touchscreen, duration)
    removeFromLRU()

    resList = []
    index = 0
    content = "layer: %s" % layer
    print content

    while (index < repeatCount):
        adb.cmd("shell dumpsys SurfaceFlinger --latency-clear")
        start_tracing(TAGS)
        dbinfo = ic.collect(packageName)
        dbinfo['name'] = packageName.split(".")[-1]  # i.e com.android.settings name: settings
        res = getLaunchTime(x, y, layer, touchscreen, duration)
        dbinfo["value"] = res
        sw.insert("launch", dbinfo)
        content = "index %d: %d ms" % (index, res)
        print content
        index += 1
        resList.append(res)
        removeFromLRU()
        stop_tracing("%s\(%d\)_%d.html" % (outputName, res, index))
    outfd.write(content)
    outfd.write("\n")

    mailmsg = []
    sum = 0
    average = 0
    for i in range(len(resList)):
        sum += resList[i]
        content = "index %d: %d ms" % (i, resList[i])
        mailmsg.append(content)
        outfd.write(content)
        outfd.write("\n")
    average = sum / len(resList)
    content = "average: %d ms" % (average)
    mailmsg.append(content)
    print content
    outfd.write(content)
    outfd.write("\n")

    resList.sort()
    content = "median = %d ms" % (resList[(len(resList) + 1) / 2])
    mailmsg.append(content)
    print content
    outfd.write(content)
    outfd.write("\n")

    outfd.close()

    rsd = RSD(resList)

    mailmsg = ("<br/>").join(mailmsg)
    mailargs = {}
    mailargs["msg"] = mailmsg
    mailargs["subject"] = "%s(%s_%s - %s) : %d ms - %d " % (packageName,
            ic.board(), ic.release(), ic.pversion(packageName), average, rsd)
    send_email(mailargs)

    return rsd


def writeList(l, out):
    fd = open(out, "w")
    for item in l:
        fd.write(item)
    fd.close()


def RSD(arr):
    n = len(arr)
    sum = 0
    for i in arr:
        sum += i
    average = sum / n

    squaresum = 0

    for i in arr:
        squaresum += (i - average) * (i - average)

    SD = math.sqrt((squaresum / (n - 1)))
    RSD = (SD / average) * 100

    return RSD
