import MySQLdb


def addquote(s):
    if isinstance(s, basestring):
        return "\"%s\"" % s
    else:
        return str(s)

class MySQLdbWrapper():

    def __init__(self):
        conn = MySQLdb.connect(host='localhost', user='root', passwd='1', port=3306)
        cur = conn.cursor()
        conn.select_db("ux")
        self.cur = cur
        self.conn = conn

    def insert(self, table, kargs):
        cmd = "insert into %s (%s) values(%s)" % (table, ", ".join(kargs.keys()), ", ".join(map(addquote, kargs.values())))
        self.cur.execute(cmd)
        self.conn.commit()

    def close(self):
        self.cur.close()
        self.conn.close()

wrapper = MySQLdbWrapper()
